let GameManager = {
  setGameStart: function (playerName) {
    this.resetPlayer(playerName);
    this.setPreFight();
  },
  resetPlayer: function (playerName) {
    switch (playerName) {
      case "King":
        player = new Player(playerName, 200, 0, 200, 100, 50);
        break;
      case "Queen":
        player = new Player(playerName, 100, 0, 100, 150, 200);
        break;
      case "Warden":
        player = new Player(playerName, 100, 0, 50, 100, 150);
        break;
      case "Wizard":
        player = new Player(playerName, 150, 0, 50, 120, 250);
        break;
    }
    let getInterface = document.querySelector(".interface");
    getInterface.innerHTML = '<img src="img/player/' + playerName.toLowerCase() + '.png" class="img-block"> <div class="info-block"><h3>' + playerName + '</h3><p>Health: ' + player.health + '</p><p>Mana: ' + player.mana + '</p><p>Strength: ' + player.strength + '</p><p>Agility: ' + player.agility + '</p><p>Speed: ' + player.speed + '</p></div>';
    getInterface.style.height = "240px";

    let getInterfaceImg = document.querySelector(".img-block");
    getInterfaceImg.style.width = "120px";
    getInterfaceImg.style.height = "120px";
    getInterfaceImg.style.display = "block";
    getInterfaceImg.style.margin = "0 auto";

    let getInterfaceInfo = document.querySelector(".info-block");
    getInterfaceInfo.style.textAlign = "center";
    getInterfaceInfo.style.lineHeight = ".1";
    getInterfaceInfo.style.fontFamily = "Acme";
    getInterfaceInfo.style.color = "white";
  },
  setPreFight: function () {
    let getHeader = document.querySelector(".header");
    let getAction = document.querySelector(".action");
    //let getArena = document.querySelector(".arena");

    getHeader.innerHTML = '<p>Task: Find an Enemy!</p>';
    getHeader.style.lineHeight = "2";

    getAction.innerHTML = '<a href="#" class="btn-prefight" onClick="GameManager.setFight()">Search for Enemy!</a>';
    getAction.style.visibility = "visible";

    //getArena.style.visibility = "visible";
  },
  setFight: function () {
    let getHeader = document.querySelector(".header");
    let getAction = document.querySelector(".action");
    let getEnemy = document.querySelector(".enemy");
    //CREATE ENEMY
    let enemy00 = new Enemy("Goblin", 100, 0, 50, 100, 100);
    let enemy01 = new Enemy("Breaker", 150, 0, 150, 50, 50);
    let enemy02 = new Enemy("Valkyrie", 170, 0, 150, 50, 150);
    let enemy03 = new Enemy("Witch", 150, 0, 100, 150, 150);

    let chooseRandomEnemy = Math.floor(Math.random() * Math.floor(4));

    switch (chooseRandomEnemy) {
      case 0:
        enemy = enemy00;
        break;
      case 1:
        enemy = enemy01;
        break;
      case 2:
        enemy = enemy02;
        break;
      case 3:
        enemy = enemy03;
        break;
    }

    getHeader.innerHTML = '<p>Task: Choose your Move!</p>';

    getAction.innerHTML = '<a href="#" class="btn-prefight" onClick="PlayerMoves.calcAttack()">Attack!</a>';

    getEnemy.innerHTML = '<img src="img/enemy/' + enemy.enemyName.toLowerCase() + '.png" class="eimg-block"> <div class="einfo-block"><h3>' + enemy.enemyName + '</h3><p>Health: ' + enemy.health + '</p><p>Mana: ' + enemy.mana + '</p><p>Strength: ' + enemy.strength + '</p><p>Agility: ' + enemy.agility + '</p><p>Speed: ' + enemy.speed + '</p></div>';
    getEnemy.style.visibility = "visible";

    let getInterfaceEImg = document.querySelector(".eimg-block");
    getInterfaceEImg.style.width = "120px";
    getInterfaceEImg.style.height = "120px";
    getInterfaceEImg.style.display = "block";
    getInterfaceEImg.style.margin = "0 auto";

    let getInterfaceEInfo = document.querySelector(".einfo-block");
    getInterfaceEInfo.style.textAlign = "center";
    getInterfaceEInfo.style.lineHeight = ".1";
    getInterfaceEInfo.style.fontFamily = "Acme";
    getInterfaceEInfo.style.color = "white";
  }
}
