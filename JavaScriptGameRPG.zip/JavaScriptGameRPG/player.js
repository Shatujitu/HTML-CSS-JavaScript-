let player;

function Player(playerName, health, mana, strength, agility, speed) {
  this.playerName = playerName;
  this.health = health;
  this.mana = mana;
  this.strength = strength;
  this.agility = agility;
  this.speed = speed;
}
