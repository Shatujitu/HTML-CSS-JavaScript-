let frontPageOff = function() {
  let getFrontPage = document.querySelector(".frontpage");
  getFrontPage.style.display = "none";
  let getAddNew = document.querySelector(".addnew");
  getAddNew.style.display = "block";
}
let addNew = function() {
  let getFrontPage = document.querySelector(".frontpage");
  getFrontPage.style.display = "block";
  let getAddNew = document.querySelector(".addnew");
  getAddNew.style.display = "none";

  let getNewValue = document.querySelector(".fp_forth");
  getNewValue.style.display = "flex";

  var name = document.querySelector("#name").value;
  var address = document.querySelector("#address").value;
  var rating = document.querySelector("#rating").value;
  var photo = document.querySelector("#addphoto").files;
  console.log(photo);

  let getName = document.querySelector(".fp_forth-1");
  getName.innerHTML = '<h5>' + name + '</h5>';
  let getAddress = document.querySelector(".fp_forth-2");
  getAddress.innerHTML = '<h5>' + address + '</h5>';
  let getRating = document.querySelector(".fp_forth-3");
  getRating.innerHTML = '<h5>' + rating + '</h5>';
  let getPhoto = document.querySelector("fp_forth-4");
  getPhoto.innerHTML = '<img src="' + photo + '" alt="">';
}
